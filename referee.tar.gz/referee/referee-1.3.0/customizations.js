// @ts-ignore
module.exports = {};
