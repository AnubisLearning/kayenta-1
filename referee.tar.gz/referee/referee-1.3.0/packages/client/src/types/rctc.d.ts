declare module 'react-copy-to-clipboard' {
  export interface CopyToClipboardProps {
    text: string;
  }
  // eslint-disable-next-line no-undef
  export class CopyToClipboard extends React.Component<CopyToClipboardProps> {}
}
