declare module 'human-format' {
  export default function humanFormat(input: number): string;
}
