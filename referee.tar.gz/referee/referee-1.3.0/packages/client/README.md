# `client`

> TODO: description

## Usage

```
const client = require('client');

// TODO: DEMONSTRATE API
```
