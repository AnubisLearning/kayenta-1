# `server`

> TODO: description

## Usage

```
const server = require('server');

// TODO: DEMONSTRATE API
```
